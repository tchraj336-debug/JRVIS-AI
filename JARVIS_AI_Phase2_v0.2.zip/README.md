# JARVIS AI — Android Phase 2 (v0.2)

A personal Android voice-assistant starter project designed with Android 10 / Redmi 9i compatibility in mind.

## Included in v0.2
- Refreshed dark futuristic dashboard with quick controls.
- Tap-to-speak Hindi speech recognition, with offline recognition preference requested from the installed speech service.
- Hindi text-to-speech; automatically prefers an installed Hindi voice whose name identifies it as female when one is available. Actual voice depends on the device TTS engine and installed voice data.
- Supported voice commands: open YouTube / WhatsApp / Chrome / Settings, Home, flashlight on/off, volume up/down, camera, alarm screen, tell time/date, and web search.
- Runtime permission handling for microphone and flashlight camera access.

## Not included yet (do not assume these work)
- Always-on “Hey Jarvis” wake-word detection or screen-off background listening.
- Connected generative AI / API key configuration.
- Uninstalling or force-stopping other apps, unrestricted system control, or reading notifications.
- Guaranteed fully offline speech recognition. `EXTRA_PREFER_OFFLINE` is a preference; the phone's speech-recognition provider and downloaded language pack decide whether it can work offline.

## Build debug APK with GitHub Actions
1. Create a GitHub repository (for example `JARVIS-AI`).
2. Upload the contents of this ZIP to the repository root, including the `.github` folder.
3. Open **Actions** → **Build JARVIS AI APK** → **Run workflow**.
4. When complete, open the workflow run and download artifact **JARVIS-AI-debug-apk**.
5. Install the APK on the phone and grant microphone permission when prompted.

The workflow builds a debug APK using Java 17 and Gradle 8.9. This source update has not been physically tested on a Redmi 9i; install and test on-device before relying on it.
